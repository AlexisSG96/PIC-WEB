1. INTRODUCTION

This is a fast getting started for using the Microchip TCP/IP stack with Olimex PIC-MAXI-WEB boards. It is highly recommended to read the excellent stack documentation from Microchip before proceeding.

2. RUNNING THE DEMO

Open "./TCPIP Demo App/PIC_MAXI_WEB_5_31.mcw" workspace. 

*NOTE: In order to compile successfully you need to have MC18 installed. Please also ensure that project directories are set properly to match path of the compiler (i.e. right-click the project->Build Options...->Directories tab).
	
Now you can compile the project and download it to the board. Of course, you can also use the project as a starting project for your custom application.

You can also use the prebuilt .hex in the respective directory to program the board.	
	
3. UPDATING THE WEB PAGE

The web pages for PIC-WEB are located in 
	.\TCPIP Demo App\WebPages2"
	
You should run the "./Microchip/TCPIP Stack/Utilities/MPFS2.exe" to regenerate the image file (default is "MPFSImg2.bin") that should be uploaded to the flash memory of the board.

Then, assuming PIC-MAXI-WEB has IP address 192.168.0.163, open the following URL in your web browser: "http://192.168.0.163/mpfsupload". Browse to "MPFSImg2.bin" and upload it. After a while waiting the new web page should be available.

4. LOCATING PIC-MAXI-WEB

Run the "./Microchip/TCPIP Stack/Utilities/Microchip Ethernet Discoverer.exe" utility in order to find what IP address has PIC-WEB fetched from DHCP. Another option is to connect a serial port to the board RS232 connector, configure your terminal application for 19200 8N1, and see the board status messages during power up.

*Note: Default setting of the board is to use DHCP to retrieve network configuration (IP address, etc.).. This can be modified by editing the "TCPIPConfig.h".

Last edit: 17 October 2012
